async startUpload() {
    try {
      this.message = 'Start Uploading Files';
      this.ngxService.start();
      let fileStreamer = new BlobStreamer(this.selectedFiles[0].file);
      
      this.fileClient = this.directoryClient.getFileClient(this.selectedFiles[0].file.name);
      let byteFile = await this.getAsByteArray(this.selectedFiles[0].file);
      this.fileSize = await Buffer.byteLength(byteFile);
      this.fileClient.create(this.fileSize);
      let initialValue = 0;
      let fileByteInfo = [];
      await this.fileClient.uploadData(this.selectedFiles[0].file, {
        rangeSize: 4 * 1024 * 1024, // 4MB range size
        concurrency: 20, // 20 concurrency
        onProgress: (ev: any) => {
          this.ngxService.stop();
          this.selectedFiles[0].value = Math.round(100 * ev.loadedBytes / this.fileSize);
          this.selectedFiles[0].LastLoadedBytes = ev.loadedBytes;
        },
        abortSignal: this.selectedFiles[0].AbortController.signal
      });
    } catch (e) {
      console.log(e + ' bassam');
      console.log(this.selectedFiles[0].LastLoadedBytes);
    }

  }