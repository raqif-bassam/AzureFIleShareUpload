import { AppService } from "../app.component.service";

export type bytes = number;

export class BlobStreamer {
  protected readonly defaultChunkSize = 4 * 1024 * 1024; // 64k (more is faster but makes chrome crash on large blobs?!)
  private offset: bytes = 0;

  constructor(private blob: Blob, private _appService: AppService) {
    this.rewind();
  }

  public rewind(bytesLength: bytes = this.offset): void {
    this.offset -= bytesLength;
  }

  public isEndOfBlob(): boolean {
    return this.offset >= this.getBlobSize();
  }

  public readBlockAsArrayBuffer(length: bytes = this.defaultChunkSize): Promise<ArrayBuffer> {

    const fileReader: FileReader = new FileReader();
    const blob: Blob = this.blob.slice(this.offset, this.offset + length);

    return new Promise<ArrayBuffer>((resolve, reject) => {
      fileReader.onload = (event: Event) => {
        const data = this.getArrayBufferFromEvent(event);
        this.shiftOffset(blob.size);
        resolve(data);
      };

      fileReader.onerror = (event: ProgressEvent,) => {
        reject(event);
      };

      fileReader.readAsArrayBuffer(blob);
    });
  }

  protected shiftOffset(bytesRead: bytes): void {
    this.offset += bytesRead;
  }

  protected getArrayBufferFromEvent(event: Event): ArrayBuffer {
    const target: FileReader = (event.target) as FileReader;
    return <ArrayBuffer>target.result;
  }

  private getTextFromEvent(event: Event): string {
    const target: FileReader = (event.target) as FileReader;
    return <string>target.result;
  }

  private testEndOfFile(): void {
    if (this.isEndOfBlob()) {
      console.log('Done reading blob');
    }
  }

  private getBlobSize(): number {
    return this.blob.size;
  }
}
