import { Component } from '@angular/core';
import { BlobStreamer } from './model/FileStreamer';
import { ShareServiceClient, FileUploadRangeResponse, ShareFileClient } from "@azure/storage-file-share";
import * as _ from 'lodash';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { AppService } from './app.component.service';
import { Guid } from 'guid-typescript';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'ClientApp';
  progressInfos: any[] = [];
  public message: string = "";
  ShowError = false;
  ErrorMessage = "";
  selectedFiles: any[] = [];
  account = "sanccscanstoragedev";
  loadingMsg = "Starting";
  sas = "?sv=2020-08-04&ss=f&srt=sco&sp=rwdlc&se=2021-10-09T02:17:52Z&st=2021-09-25T18:17:52Z&sip=118.179.50.49&spr=https,http&sig=CA9faaP5yUPS4D2ZvPyzW76jsbsSvjn4dv4QpjjFh1A%3D&api-version=2020-08-04";

  serviceClientWithSAS = new ShareServiceClient(
    `https://${this.account}.file.core.windows.net${this.sas}`
  );
  shareName = "scan";
  directoryName = "Bassam-Test";
  parallelFileUploadCount = 4;
  fileClient: any;
  shareClient = this.serviceClientWithSAS.getShareClient(this.shareName);
  directoryClient = this.shareClient.getDirectoryClient(this.directoryName);
  errorFileList: any[] = [];
  fileByteInfo: any[] = [];
  constructor(private ngxService: NgxUiLoaderService, private _appService: AppService) {

  }


  fileChange(event: any): void {
    this.progressInfos = [];
    this.selectedFiles = [];
    let files = event.target.files;
    _.each(files, (file) => {
      file.Id = Guid.create();
      file.file = file;
      file.ProgressPercentage = 0;
      file.AbortController = new AbortController();
      file.IsPause = false;
      file.IsUploaded = false;
      file.IsInProgress = false;
      file.LastLoadedBytes = 0;
      file.UploadedChunk = 0;
      file.FileOriginalSize = 0;
      file.PromiseArray = []
      this.selectedFiles.push(file);
    })
  }


  removeFile(file: any, element: any) {
    this.selectedFiles = _.remove(this.selectedFiles, (item) => { item.Id === file.Id });
    if (this.selectedFiles.length === 0) {
      element.value = "";
      this.message = "";
    }
  }

  pauseUpload(file: any) {
    file.IsPause = true;
    //file.PromiseArray.push(Promise.reject("Paused!"));
    file.PromiseArray = [];
    console.log(file.LastLoadedBytes);
  }

  abortUpload(file: any) {
    file.AbortController.abort();
  }

  async getAsByteArray(file: File) {
    return new Uint8Array(await this.readFile(file))
  }

  readFile(file: File) {
    return new Promise<ArrayBufferLike>((resolve, reject) => {
      // Create file reader
      let reader = new FileReader()

      // Register event listeners
      reader.addEventListener("loadend", (e: any) => resolve(e.target.result))
      reader.addEventListener("error", reject)

      // Read file
      reader.readAsArrayBuffer(file)
    })
  }

  async resumeUpload(file: any) {
    let isAnyUploadInProgress = _.filter(this.selectedFiles, (item) => { return item.IsInProgress === true });
    if (isAnyUploadInProgress.length > 0) {
      alert("Cannot Resume Upload Until All the upload Finishes");
      return;
    }

    let shareFileClient = this.directoryClient.getFileClient(file.file.name);
    let selectedFile = file.file.slice(file.file.LastLoadedBytes, file.FileOriginalSize);
    let fileStreamer = new BlobStreamer(selectedFile, this._appService);
    file.IsPause = false;
    await this.UploadToAzure(fileStreamer, shareFileClient, file, file.LastLoadedBytes);
  }

  async startUpload() {

    if (this.selectedFiles.length === 0) {
      this.ShowError = true;
      this.ErrorMessage = "Please Select File";
      return;
    }

    this.message = 'Uploading Files';
    this.ngxService.start();
    for (let file of this.selectedFiles) {
      this.ShowError = false;
      let fileStreamer = new BlobStreamer(file.file, this._appService);
      let shareClient = this.serviceClientWithSAS.getShareClient(this.shareName);
      let directoryClient = shareClient.getDirectoryClient(this.directoryName);
      let fileClient = directoryClient.getFileClient(file.file.name);
      let byteFile = await this.getAsByteArray(file.file);
      file.FileOriginalSize = Buffer.byteLength(byteFile);
      fileClient.create(file.FileOriginalSize);
      await this.UploadToAzure(fileStreamer, fileClient, file);
    }
    this.message = 'Uploading Completed';
  }

  async UploadToAzure(fileStreamer: BlobStreamer, fileClient: ShareFileClient, file: any, previousFileChunk = 0) {
    try {
      let initialValue = 0;
      this.fileByteInfo = [];
      file.IsInProgress = true;
      while (!fileStreamer.isEndOfBlob()) {
        const data = await fileStreamer.readBlockAsArrayBuffer();
        let blob = file.file.slice(initialValue, initialValue + data.byteLength);
        this.fileByteInfo.push({ sliceByte: data, fileSlice: blob, offset: initialValue, shareClient: fileClient });
        initialValue += data.byteLength;
      }

      let arrayChunk: any[] = _.chunk(this.fileByteInfo, this.parallelFileUploadCount);
      let percentComplete = file.UploadedChunk > 0 ? file.UploadedChunk : 0;
      for (let itemArray of arrayChunk) {
        file.PromiseArray = [];
        for (let i = 0; i < itemArray.length; i++) {
          file.PromiseArray.push(
            itemArray[i].shareClient.uploadRange(itemArray[i].fileSlice, itemArray[i].offset, itemArray[i].sliceByte.byteLength)
          );
        }
        if (!file.IsPause) {
          await Promise.all(file.PromiseArray).then((result: any[]) => {
            this.ngxService.stop();
            file.LastLoadedBytes = itemArray[itemArray.length - 1].offset + this._appService.getDefultChunkSize();
            file.LastLoadedBytes = previousFileChunk > 0 ? file.LastLoadedBytes + previousFileChunk : file.LastLoadedBytes
            percentComplete += result.length;
            file.UploadedChunk = percentComplete;
            file.ProgressPercentage = Math.round(100 * file.LastLoadedBytes / file.FileOriginalSize) > 100 ? 100 : Math.round(100 * file.LastLoadedBytes / file.FileOriginalSize);
            file.IsUploaded = file.ProgressPercentage === 100 ? true : false
            file.IsInProgress = file.ProgressPercentage === 100 ? false : true;
          }).catch(e => console.log(e));
        }
        else {
          this.fileByteInfo = [];
          file.IsInProgress = false;
          break;
        }
      }
    } catch (e) {
      this.errorFileList.push(file);
      console.log(e);
    }
  }
}

