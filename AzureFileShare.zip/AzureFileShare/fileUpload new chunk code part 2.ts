async startUpload() {
    this.message = 'Start Uploading FIles';
    this.ngxService.start();
    let fileStreamer = new BlobStreamer(this.selectedFiles[0]);
    let shareClient = this.serviceClientWithSAS.getShareClient(this.shareName);
    let directoryClient = shareClient.getDirectoryClient(this.directoryName);
    let fileClient = directoryClient.getFileClient(this.selectedFiles[0].name);
    let byteFile = await this.getAsByteArray(this.selectedFiles[0]);
    this.fileSize = await Buffer.byteLength(byteFile);
    fileClient.create(this.fileSize);
    let initialValue = 0;
    let fileByteInfo = [];
    while (!fileStreamer.isEndOfBlob()) {
      const data = await fileStreamer.readBlockAsArrayBuffer();
      let blob = this.selectedFiles[0].slice(initialValue, initialValue + data.byteLength);
      fileByteInfo.push({ sliceByte: data, fileSlice: blob, offset: initialValue, shareClient: fileClient });
      initialValue += data.byteLength;
    }
    let promiseArray: Promise<FileUploadRangeResponse>[] = [];
    let arrayChunk = _.chunk(fileByteInfo, this.parallelFileUploadCount);
    let percentComplete = 0;
    _.each(arrayChunk, (itemArray) => {
      promiseArray = [];
      for (let i = 0; i < itemArray.length; i++) {
        promiseArray.push(itemArray[i].shareClient.uploadRange(itemArray[i].fileSlice, itemArray[i].offset, itemArray[i].sliceByte.byteLength, { onProgress: (event) => { this.selectedFiles[0].value = Math.round(100 * event.loadedBytes / this.fileSize) } }));
      }
      Promise.all(promiseArray).then(result => {
        this.ngxService.stop();
        percentComplete += result.length;
        this.selectedFiles[0].value = Math.round(100 * percentComplete / fileByteInfo.length);
        //_.each(result, item => {
        //  console.log(item.contentMD5?.buffer);
        //})
      });
    });

    //console.log(fileByteInfo);
  }

  async UploadToAzure(fileStreamer: BlobStreamer, fileClient: ShareFileClient, file: any) {
    let initialValue = 0;

    let test = 0;
    let fileByteInfo = [];
    while (!fileStreamer.isEndOfBlob()) {
      const data = await fileStreamer.readBlockAsArrayBuffer();
      let blob = file.file.slice(initialValue, initialValue + data.byteLength);
      fileByteInfo.push({ sliceByte: data, fileSlice: blob, offset: initialValue, shareClient: fileClient });
      initialValue += data.byteLength;
    }
    let promiseArray: Promise<FileUploadRangeResponse>[] = [];
    let arrayChunk = _.chunk(fileByteInfo, this.parallelFileUploadCount);
    let percentComplete = file.UploadedChunk > 0 ? file.UploadedChunk : 0;
    for (let itemArray of arrayChunk) {
      promiseArray = [];
      for (let i = 0; i < itemArray.length; i++) {
        promiseArray.push(
          itemArray[i].shareClient.uploadRange(itemArray[i].fileSlice, itemArray[i].offset, itemArray[i].sliceByte.byteLength,
            {
              onProgress: (ev) => {
                  file.LastLoadedBytes = ev.loadedBytes;
              }
            }
          )
        );
      }
      if (!file.IsPause) {
        await Promise.all(promiseArray).then((result: any[]) => {
          percentComplete += result.length;
          file.UploadedChunk = percentComplete;
          file.value = Math.round(100 * percentComplete / fileByteInfo.length);
          test += file.LastLoadedBytes;
        });
      }
    }
  }