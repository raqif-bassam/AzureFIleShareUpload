﻿using Azure;
using Azure.Storage.Files.Shares;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Storage;
using Microsoft.Azure.Storage.DataMovement;
using Microsoft.Azure.Storage.File;
using Serilog;
using System;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
namespace AzureFileShare.Controllers
{
    public class HomeController : Controller
    {
        private CloudStorageAccount _storageAccount;
        private CloudFileClient _cloudFileClient;
        private const long MaxFileSize = 10L * 1024L * 1024L * 1024L; // 10GB, adjust to your need
        public IActionResult Index()
        {
            return View();
        }

      
        [HttpPost,DisableRequestSizeLimit]
        [Route("api/home/upload")]
        public async Task UploadFiles(IFormCollection files)
        {

            string connectionString = "DefaultEndpointsProtocol=https;AccountName=sanccscanstoragedev;AccountKey=W24/TWVXtcFFE4D1+Ik31WsaaHGmsrWazX/6jGL1rmyGt+vu0lW188NS7HlkSTIHGGkvKQNN041SNB8DaPk4xw==;EndpointSuffix=core.windows.net";
            string shareName = "scan";
            string dirName = "Bassam-Test";
            ShareClient share = new ShareClient(connectionString, shareName);
            await share.CreateIfNotExistsAsync();
            ShareDirectoryClient directory = share.GetDirectoryClient(dirName);
            await directory.CreateIfNotExistsAsync();
            foreach (var fileObj in files.Files)
            {
                try
                {
                    string fileName = fileObj.FileName;
                    ShareFileClient file = directory.GetFileClient(fileName);
                    CloudFile fileStore = await GetCloudFileAsync("scan", fileName, dirName);
                    //using (FileStream stream = new FileStream(localFilePath, FileMode.Open, FileAccess.Read))
                    //{
                    //    file.Create(stream.Length);
                    //    file.UploadRange(
                    //        new HttpRange(0, stream.Length),
                    //        stream);
                    //}
                    using (Stream stream = fileObj.OpenReadStream())
                    {
                        //await file.CreateAsync(stream.Length);
                        await file.UploadRangeAsync(
                            new HttpRange(0, stream.Length),
                            stream);
                            
                        TransferManager.Configurations.ParallelOperations = 64;
                        // Setup the transfer context and track the upload progress
                        SingleTransferContext context = new SingleTransferContext();
                        context.ProgressHandler = new Progress<TransferStatus>((progress) =>
                        {
                            Console.WriteLine("Bytes uploaded: {0}", progress.BytesTransferred);
                        });
                        // Upload a local file share
                        var task = TransferManager.UploadAsync(stream, fileStore, null, context, CancellationToken.None);
                        task.Wait();

                    }
                }
                catch (Exception exp)
                {
                    Log.Error(exp, exp.Message);
                }
            }
        }

        public async Task<CloudFile> GetCloudFileAsync(string shareName, string fileName, string folderName)
        {
            CloudFileClient client = GetCloudFileClient();
            CloudFileShare share = client.GetShareReference(shareName);
            await share.CreateIfNotExistsAsync();

            CloudFileDirectory rootDirectory = share.GetRootDirectoryReference();
            CloudFileDirectory customDirectory = rootDirectory.GetDirectoryReference(folderName);
            return customDirectory.GetFileReference(fileName);
        }
        private CloudFileClient GetCloudFileClient()
        {
            if (_cloudFileClient == null)
            {
                _cloudFileClient = GetStorageAccount().CreateCloudFileClient();
            }

            return _cloudFileClient;
        }
        private CloudStorageAccount GetStorageAccount()
        {
            if (_storageAccount == null)
            {
                string connectionString = "DefaultEndpointsProtocol=https;AccountName=sanccscanstoragedev;AccountKey=W24/TWVXtcFFE4D1+Ik31WsaaHGmsrWazX/6jGL1rmyGt+vu0lW188NS7HlkSTIHGGkvKQNN041SNB8DaPk4xw==;EndpointSuffix=core.windows.net";
                _storageAccount = CloudStorageAccount.Parse(connectionString);
            }

            return _storageAccount;
        }

        public IActionResult About()
        {
            ViewData["Message"] = "Your application description page.";

            return View();
        }

        public IActionResult Contact()
        {
            ViewData["Message"] = "Your contact page.";

            return View();
        }
    }
}
