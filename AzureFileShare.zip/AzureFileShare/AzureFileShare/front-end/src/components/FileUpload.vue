<template>
    <div class="container">
        <h1>{{ msg }}</h1>
        <form class="row g-3 mt-2 d-flex justify-content-center">
            <div class="col-auto">
                <input type="file" multiple @change="fileChange($event.target.files)" class="form-control" />
            </div>
            <div class="col-auto">
                <button class="btn btn-primary" @click="startUpload()" type="button">Upload File(s)</button>
            </div>
            <div v-for="(file, key) in files" class="file-listing">{{ file.name }} <span class="remove-file" v-on:click="removeFile( key )">Remove</span></div>
        </form>
    </div>
</template>

<script>
    import axios from "axios"
    export default {
        name: "FileUploader",
        props: {
            msg: String,
        },
        data: function () {
            return {
                //files: new FormData()
                files:[]
            }
        },
        methods: {
            startUpload() {

                let formData = new FormData();
                for (var i = 0; i < this.files.length; i++) {
                    let file = this.files[i];
                    formData.append('files[' + i + ']', file, file.name);
                }

                axios.post(`/api/home/upload`,
                    formData,
                    {
                        headers: {
                            'Content-Type': 'multipart/form-data'
                        }
                    }).then(() => {
                        alert(`Total Mock File Uploaded: ${this.files.length}`);
                    }).catch(error => {
                        alert(`something went wrong: ${error}`);
                    });
            },
            fileChange(fileList) {
                //let filesToBeUploaded = new FormData();

                //console.log(this.files);
                //for (let i = 0; i < fileList.length; i++) {
                //    this.filesToBeUploaded.append("file", fileList[i], fileList[i].name);
                //}

                this.files = fileList;
            }
        }
    };
</script>
