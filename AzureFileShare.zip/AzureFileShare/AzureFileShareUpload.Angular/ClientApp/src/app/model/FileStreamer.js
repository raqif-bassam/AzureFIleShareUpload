"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BlobStreamer = void 0;
var BlobStreamer = /** @class */ (function () {
    function BlobStreamer(blob, _appService) {
        this.blob = blob;
        this._appService = _appService;
        this.defaultChunkSize = 4 * 1024 * 1024; // 64k (more is faster but makes chrome crash on large blobs?!)
        this.offset = 0;
        this.rewind();
    }
    BlobStreamer.prototype.rewind = function (bytesLength) {
        if (bytesLength === void 0) { bytesLength = this.offset; }
        this.offset -= bytesLength;
    };
    BlobStreamer.prototype.isEndOfBlob = function () {
        return this.offset >= this.getBlobSize();
    };
    BlobStreamer.prototype.readBlockAsArrayBuffer = function (length) {
        var _this = this;
        if (length === void 0) { length = this.defaultChunkSize; }
        var fileReader = new FileReader();
        var blob = this.blob.slice(this.offset, this.offset + length);
        return new Promise(function (resolve, reject) {
            fileReader.onload = function (event) {
                var data = _this.getArrayBufferFromEvent(event);
                _this.shiftOffset(blob.size);
                resolve(data);
            };
            fileReader.onerror = function (event) {
                reject(event);
            };
            fileReader.readAsArrayBuffer(blob);
        });
    };
    BlobStreamer.prototype.shiftOffset = function (bytesRead) {
        this.offset += bytesRead;
    };
    BlobStreamer.prototype.getArrayBufferFromEvent = function (event) {
        var target = (event.target);
        return target.result;
    };
    BlobStreamer.prototype.getTextFromEvent = function (event) {
        var target = (event.target);
        return target.result;
    };
    BlobStreamer.prototype.testEndOfFile = function () {
        if (this.isEndOfBlob()) {
            console.log('Done reading blob');
        }
    };
    BlobStreamer.prototype.getBlobSize = function () {
        return this.blob.size;
    };
    return BlobStreamer;
}());
exports.BlobStreamer = BlobStreamer;
//# sourceMappingURL=FileStreamer.js.map