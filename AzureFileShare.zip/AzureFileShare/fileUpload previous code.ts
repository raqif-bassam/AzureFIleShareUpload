startUpload() {
    this.message = 'Start Uploading FIles';
    this.ngxService.start();
    Array.from(this.selectedFiles).forEach(async (item, index) => {
      //this.progressInfos[index] = { value: 0, fileName: item.name };
      let fileStreamer = new BlobStreamer(item);
      let shareClient = this.serviceClientWithSAS.getShareClient(this.shareName);
      let directoryClient = shareClient.getDirectoryClient(this.directoryName);
      let fileClient = directoryClient.getFileClient(item.name);
      let byteFile = await this.getAsByteArray(item);
      let fileSize = Buffer.byteLength(byteFile);
      await fileClient.create(fileSize);
      let initialValue = 0;
      while (!fileStreamer.isEndOfBlob()) {
        const data = await fileStreamer.readBlockAsArrayBuffer();
        let blob = this.selectedFiles[0].slice(initialValue, initialValue + data.byteLength);
        await fileClient.uploadRange(blob, initialValue, data.byteLength);
        this.ngxService.stop();
        initialValue += data.byteLength;
        //this.progressInfos[index].value = Math.round(100 * initialValue / fileSize);
        item.value = Math.round(100 * initialValue / fileSize);
      }
    })
  }